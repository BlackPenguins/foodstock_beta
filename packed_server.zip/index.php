<!DOCTYPE html>
<html>
    <head>
        <title>Another SSD VPS from Vultr.com!</title>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
        <style>
            .link:hover {
                text-decoration: none;
                                color:#f7ff03;
            }
        </style>
    </head>
    <body style="position: relative; min-height: 100%; margin: 0px; padding: 0px; background-color: #0b4182; font-family: Arial, sans-serif;">
        <div style="position: absolute; top: 0px; left: 0px; width: 100%; min-height: 100%; background: linear-gradient(0deg, #0b4182 1%, #1e88e5 100%);">

            <div style="margin-top: 150px; text-align: center;">
                <div class='link' style='margin:30px;'>
                                <a href="http://penguinore.net/sodastock.php">
                    <span style="text-decoration: none; color: #ffffff; font-size: 50px;">Go to SodaStock &gt;&gt;</span>
                </a>
                                </div>
                                <div class='link' style='margin:30px;'>
                                <a href="http://penguinore.net/snackstock.php">
                                        <span style="text-decoration: none; color: #ffffff; font-size: 50px;">Go to SnackStock &gt;&gt;</span>
                                </a>
                                </div>
            </div>

        </div>
    </body>
</html>
