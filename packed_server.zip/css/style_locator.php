<?php
    include(__DIR__ . "/../appendix.php" );
    echo "<link rel='stylesheet' type='text/css' href='" . CSS_LINK . "'/>";
    echo "<link rel='stylesheet' type='text/css' href='" . CSS_LIGHTS_LINK . "'/>";
?>