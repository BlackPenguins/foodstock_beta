<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<?php
    include( "appendix.php" );
    include(FOODSTOCK_PATH);
    main(SNACKSTOCK_LINK, "Snack", "snack", "cabinet");
?>
</body>