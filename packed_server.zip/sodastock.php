<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<?php
    include( "appendix.php" );
    include(FOODSTOCK_PATH);
    main(SODASTOCK_LINK, "Soda", "soda", "fridge");
?>
</body>