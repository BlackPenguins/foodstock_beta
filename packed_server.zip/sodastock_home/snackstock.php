<!DOCTYPE html>
<html>
    <head>
        <title>Another SSD VPS from Vultr.com!</title>
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
        <style>
            a,
            a:link,
            a:visited,
            a:active,
            a:hover {
                text-decoration: none;
                color:#ffd333;
            }
        </style>
    </head>
    <body style="position: relative; min-height: 100%; margin: 0px; padding: 0px; background-color: #0b4182; font-family: Arial, sans-serif;">
        <div style="position: absolute; top: 0px; left: 0px; width: 100%; min-height: 100%; background: linear-gradient(0deg, #0b4182 1%, #1e88e5 100%);">

            <div style="margin-top: 150px; text-align: center;">
                    <img src="logo.png" alt="VULTR™" style="width: 100%; min-width: 100px; max-width: 502px; height: auto; padding: 16px; box-sizing: border-box;"/><br/>
                    <span style="text-decoration: none; color: #ffffff; font-size: 24px;">We are now hosted by Vultr.com!</span><br>
                    <span style="text-decoration: none; color: #ffffff; font-size: 24px;">Find the new site here: <a href='https://penguinore.net/sodastock.php'>http://penguinore.net/sodastock.php</a></span>
            </div>

        </div>
    </body>
</html>
